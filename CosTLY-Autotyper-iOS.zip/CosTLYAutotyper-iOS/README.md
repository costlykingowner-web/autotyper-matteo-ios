# CosTLY's Autotyper (iOS keyboard edition)
Built with GitHub Actions (macOS runner): upload CosTLY-Autotyper-iOS.zip to a repo, add .github/workflows/ios.yml, download the .ipa artifact, sideload with AltStore or Sideloadly.
