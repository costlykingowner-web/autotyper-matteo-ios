import Foundation
import CryptoKit
import UIKit

struct LicenseInfo {
    var valid = false
    var daysLeft: Int? = nil
    var message = "Not activated"
}

/// Same access-key system as the Android app (keys from keygen.py work on both).
enum License {
    private static let secret = "cc65987388f79e159581a2d921cd4f9ecc87d805c21da7cd"
    private static let alphabet = Array("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567")
    private static var d: UserDefaults { Shared.defaults }

    /// e.g. "K7QD-M2XA" - send it to the owner to get a key locked to this device.
    static func deviceID() -> String {
        if let s = d.string(forKey: "deviceID") { return s }
        let raw = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        let h = Array(SHA256.hash(data: Data(("costly:" + raw).utf8)))
        let b = base32Encode(Array(h[0..<5]))
        let id = String(b.prefix(4)) + "-" + String(b.suffix(4))
        d.set(id, forKey: "deviceID")
        return id
    }

    private static func deviceTag() -> [UInt8] {
        let norm = deviceID().replacingOccurrences(of: "-", with: "")
        return Array(Array(SHA256.hash(data: Data(("tag:" + norm).utf8)))[0..<4])
    }

    static func current() -> LicenseInfo {
        guard let key = d.string(forKey: "licenseKey") else { return LicenseInfo() }
        return check(key)
    }

    /// Returns nil on success, otherwise an error message.
    static func activate(_ input: String) -> String? {
        let r = check(input)
        if !r.valid { return r.message }
        d.set(input.trimmingCharacters(in: .whitespacesAndNewlines), forKey: "licenseKey")
        return nil
    }

    static func deactivate() { d.removeObject(forKey: "licenseKey") }

    private static func todayDay() -> Int {
        let now = Date().timeIntervalSince1970
        let seen = d.double(forKey: "seen")
        let t = max(now, seen)               // clock-rollback protection
        if t - seen > 3600 { d.set(t, forKey: "seen") }
        return Int(t / 86400)
    }

    static func check(_ input: String) -> LicenseInfo {
        var s = String(input.uppercased().filter { $0.isLetter || $0.isNumber })
        if s.count == 30 && s.hasPrefix("COSTLY") { s = String(s.dropFirst(6)) }
        guard s.count == 24, let raw = base32Decode(s), raw.count == 15 else {
            return LicenseInfo(message: "Invalid key format")
        }
        let payload = Array(raw[0..<8])
        let mac = Array(raw[8..<15])
        let code = HMAC<SHA256>.authenticationCode(for: Data(payload), using: SymmetricKey(data: Data(secret.utf8)))
        let expected = Array(Array(code)[0..<7])
        guard mac == expected else { return LicenseInfo(message: "Invalid key") }

        let rawExp = (UInt32(payload[0]) << 24) | (UInt32(payload[1]) << 16) | (UInt32(payload[2]) << 8) | UInt32(payload[3])
        let bound = (rawExp & 0x8000_0000) != 0       // top bit = locked to one device
        let expiry = Int(rawExp & 0x7FFF_FFFF)
        if bound && Array(payload[4..<8]) != deviceTag() {
            return LicenseInfo(message: "This key is locked to another device")
        }
        if expiry == 0 { return LicenseInfo(valid: true, daysLeft: nil, message: "Lifetime") }
        let today = todayDay()
        if today > expiry { return LicenseInfo(message: "This key has expired") }
        let left = expiry - today
        return LicenseInfo(valid: true, daysLeft: left, message: left == 1 ? "Expires in 1 day" : "Expires in \(left) days")
    }

    private static func base32Decode(_ s: String) -> [UInt8]? {
        var buffer = 0
        var bits = 0
        var out = [UInt8]()
        for ch in s {
            guard let v = alphabet.firstIndex(of: ch) else { return nil }
            buffer = (buffer << 5) | v
            bits += 5
            if bits >= 8 {
                out.append(UInt8((buffer >> (bits - 8)) & 0xFF))
                bits -= 8
                buffer &= (1 << bits) - 1
            }
        }
        return out
    }

    private static func base32Encode(_ data: [UInt8]) -> String {
        var out = ""
        var buffer = 0
        var bits = 0
        for b in data {
            buffer = (buffer << 8) | Int(b)
            bits += 8
            while bits >= 5 {
                out.append(alphabet[(buffer >> (bits - 5)) & 31])
                bits -= 5
            }
            buffer &= (1 << bits) - 1
        }
        if bits > 0 { out.append(alphabet[(buffer << (5 - bits)) & 31]) }
        return out
    }
}
