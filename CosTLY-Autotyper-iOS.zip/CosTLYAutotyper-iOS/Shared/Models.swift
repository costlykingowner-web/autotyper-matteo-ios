import SwiftUI

let brandName = "CosTLY's Autotyper"

enum Brand {
    static let bg = Color(hex: 0x0A0E1A)
    static let surface = Color(hex: 0x121829)
    static let surface2 = Color(hex: 0x1A2138)
    static let violet = Color(hex: 0x8B5CF6)
    static let cyan = Color(hex: 0x22D3EE)
    static let mint = Color(hex: 0x34D399)
    static let amber = Color(hex: 0xFBBF24)
    static let rose = Color(hex: 0xF87171)
    static let muted = Color(hex: 0x8B93AB)
    static let gradient = LinearGradient(colors: [violet, cyan], startPoint: .leading, endPoint: .trailing)
}

extension Color {
    init(hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xFF) / 255.0,
                  green: Double((hex >> 8) & 0xFF) / 255.0,
                  blue: Double(hex & 0xFF) / 255.0)
    }
}

/// Logo: gradient tile, a "C" and a typing caret.
struct BrandLogo: View {
    var size: CGFloat = 44
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.28)
                .fill(LinearGradient(colors: [Brand.violet, Brand.cyan], startPoint: .topLeading, endPoint: .bottomTrailing))
            Circle()
                .trim(from: 40.0 / 360.0, to: 320.0 / 360.0)
                .stroke(Color.white, style: StrokeStyle(lineWidth: size * 0.11, lineCap: .round))
                .frame(width: size * 0.4, height: size * 0.4)
                .offset(x: -size * 0.04)
            Capsule()
                .fill(Color(hex: 0xE0F7FF))
                .frame(width: size * 0.07, height: size * 0.22)
                .offset(x: size * 0.26)
        }
        .frame(width: size, height: size)
    }
}

// MARK: - Data

struct Wordlist: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var lines: [String]
    var loop = false
    var shuffle = false
    var lineCount: Int { lines.filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }.count }
}

struct TypingConfig: Codable, Equatable {
    var wpm = 60            // 10...3000
    var jitter = true       // +-15% per keystroke
    var delayBetweenMs = 300
    var autoSend = true     // presses Return after every line
    /// ms per character = 60000 / (WPM * 5)
    var baseCharDelayMs: Double { 60000.0 / (Double(min(max(wpm, 10), 3000)) * 5.0) }
}

/// Slider fraction (0...1) <-> WPM. Squared curve = fine control at low speed, still reaches 3000.
func wpmFromFraction(_ f: Double) -> Int {
    let x = min(max(f, 0), 1)
    return Int((10.0 + 2990.0 * x * x).rounded())
}
func fractionFromWpm(_ w: Int) -> Double {
    (Double(max(w - 10, 0)) / 2990.0).squareRoot()
}

// MARK: - Storage shared between the app and the keyboard

enum Shared {
    /// AltStore rewrites the app-group id at install time and exposes it via ALTAppGroups.
    static var groupID: String {
        if let arr = Bundle.main.object(forInfoDictionaryKey: "ALTAppGroups") as? [String], let g = arr.first { return g }
        return "group.com.costly.autotyper"
    }
    static let defaults: UserDefaults = UserDefaults(suiteName: groupID) ?? .standard
}

final class Store {
    static let shared = Store()
    private var d: UserDefaults { Shared.defaults }
    private let enc = JSONEncoder()
    private let dec = JSONDecoder()

    var lists: [Wordlist] {
        get {
            guard let data = d.data(forKey: "lists") else { return [] }
            return (try? dec.decode([Wordlist].self, from: data)) ?? []
        }
        set { d.set(try? enc.encode(newValue), forKey: "lists") }
    }
    var activeID: String? {
        get { d.string(forKey: "activeID") }
        set { d.set(newValue, forKey: "activeID") }
    }
    var config: TypingConfig {
        get {
            guard let data = d.data(forKey: "config") else { return TypingConfig() }
            return (try? dec.decode(TypingConfig.self, from: data)) ?? TypingConfig()
        }
        set { d.set(try? enc.encode(newValue), forKey: "config") }
    }
}
