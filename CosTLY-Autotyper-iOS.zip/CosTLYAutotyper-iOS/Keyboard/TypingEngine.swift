import SwiftUI
import UIKit

/// Types the active wordlist through the keyboard's text document proxy, character by character.
@MainActor
final class TypingEngine: ObservableObject {
    enum Status { case idle, typing, paused }

    @Published var status: Status = .idle
    @Published var position = 0
    @Published var total = 0
    @Published var message = ""
    @Published var config = Store.shared.config
    @Published var lists: [Wordlist] = Store.shared.lists
    @Published var activeID: String? = Store.shared.activeID
    @Published var license = License.current()

    weak var proxy: UITextDocumentProxy?
    private var task: Task<Void, Never>?
    private var order: [Int] = []
    private var typedCount = 0      // characters typed for the current (unsent) line
    private var skipTick = 0

    var activeList: Wordlist? { lists.first { $0.id.uuidString == activeID } ?? lists.first }
    private func lines() -> [String] {
        (activeList?.lines ?? []).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
    }

    func reload() {
        lists = Store.shared.lists
        activeID = Store.shared.activeID ?? lists.first?.id.uuidString
        config = Store.shared.config
        license = License.current()
        total = lines().count
    }

    // MARK: settings used by the keyboard UI
    func setWpm(_ v: Int) { config.wpm = v; Store.shared.config = config }
    func setAutoSend(_ v: Bool) { config.autoSend = v; Store.shared.config = config }
    func select(_ l: Wordlist) {
        activeID = l.id.uuidString
        Store.shared.activeID = activeID
        order = []
        stop()
    }

    func activateFromClipboard() {
        guard let s = UIPasteboard.general.string, !s.isEmpty else {
            message = "Clipboard is empty (turn on Allow Full Access)"; return
        }
        if let err = License.activate(s) { message = err } else { license = License.current(); message = "" }
    }

    func pasteList() {
        guard let s = UIPasteboard.general.string else { message = "Clipboard is empty (turn on Allow Full Access)"; return }
        let ls = s.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        guard !ls.isEmpty else { message = "Nothing to paste"; return }
        let new = Wordlist(name: "Pasted list", lines: ls)
        var all = Store.shared.lists
        all.append(new)
        Store.shared.lists = all
        Store.shared.activeID = new.id.uuidString
        reload()
        order = []
        stop()
    }

    // MARK: playback
    func play() {
        license = License.current()
        guard license.valid else { message = "Activate a valid access key first"; return }
        guard !lines().isEmpty else { message = "The wordlist is empty"; return }
        guard proxy != nil else { return }
        if status == .typing { return }
        message = ""
        status = .typing
        task?.cancel()
        task = Task { await self.run() }
    }

    func pause() {
        guard status == .typing else { return }
        task?.cancel()
        clearTyped()
        status = .paused
        message = "Paused"
    }

    func stop() {
        task?.cancel()
        clearTyped()
        status = .idle
        position = 0
        message = ""
        total = lines().count
    }

    func skip() {
        if status == .typing {
            skipTick += 1
        } else {
            position = (position + 1 >= total) ? 0 : position + 1
        }
    }

    private func clearTyped() {
        for _ in 0..<typedCount { proxy?.deleteBackward() }
        typedCount = 0
    }

    private func halt(_ s: Status, _ m: String) {
        status = s
        message = m
    }

    private func sleepMs(_ ms: Double) async -> Bool {
        do {
            try await Task.sleep(nanoseconds: UInt64(max(ms, 0) * 1_000_000))
            return true
        } catch {
            return false
        }
    }

    private func run() async {
        guard let list = activeList else { halt(.idle, "No wordlist selected"); return }
        let ls = lines()
        guard !ls.isEmpty else { halt(.idle, "The wordlist is empty"); return }
        if order.count != ls.count {
            order = Array(0..<ls.count)
            if list.shuffle { order.shuffle() }
        }
        total = ls.count

        while !Task.isCancelled {
            if position >= order.count {
                if list.loop {
                    position = 0
                    if list.shuffle { order.shuffle() }
                } else {
                    halt(.idle, "Finished")
                    position = 0
                    return
                }
            }
            let chars = Array(ls[order[position]])
            let tick = skipTick
            var i = 0

            // ---- type the line ----
            while i < chars.count {
                if Task.isCancelled { return }
                if skipTick != tick { break }
                guard let p = proxy else { halt(.paused, "Keyboard closed"); return }
                var d = config.baseCharDelayMs
                if config.jitter { d *= Double.random(in: 0.85...1.15) }
                d = max(d, 1)
                // At very high WPM, type several characters per step.
                let batch = d < 15 ? Int((15.0 / d).rounded(.up)) : 1
                let end = min(i + batch, chars.count)
                let n = end - i
                let chunk = String(chars[i..<end])
                p.insertText(chunk)
                typedCount += chunk.count
                i = end
                if !(await sleepMs(d * Double(n))) { return }
            }

            if skipTick != tick {          // skipped mid-line
                clearTyped()
                position += 1
                continue
            }

            // ---- send ----
            if config.autoSend {
                guard let p = proxy else { halt(.paused, "Keyboard closed"); return }
                p.insertText("\n")
                typedCount = 0
                if !(await sleepMs(250)) { return }
                if proxy?.hasText == true {
                    position += 1
                    halt(.paused, "This app didn't send on Return - paused")
                    return
                }
                position += 1
            } else {
                typedCount = 0
                position += 1
                halt(.paused, "Typed - send it, then press Play")
                return
            }

            // ---- wait before the next message ----
            var left = config.delayBetweenMs
            while left > 0 {
                let step = min(100, left)
                if !(await sleepMs(Double(step))) { return }
                left -= step
                if skipTick != tick { position += 1; break }
            }
        }
    }
}
