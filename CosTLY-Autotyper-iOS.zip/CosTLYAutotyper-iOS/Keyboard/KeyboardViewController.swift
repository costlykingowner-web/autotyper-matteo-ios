import UIKit
import SwiftUI

@objc(KeyboardViewController)
class KeyboardViewController: UIInputViewController {
    private let engine = TypingEngine()
    private var host: UIHostingController<KeyboardRoot>?

    override func viewDidLoad() {
        super.viewDidLoad()
        engine.proxy = textDocumentProxy
        engine.reload()

        let root = KeyboardRoot(
            engine: engine,
            hasFullAccess: hasFullAccess,
            nextKeyboard: { [weak self] in self?.advanceToNextInputMode() }
        )
        let h = UIHostingController(rootView: root)
        addChild(h)
        view.addSubview(h.view)
        h.view.translatesAutoresizingMaskIntoConstraints = false
        h.view.backgroundColor = .clear
        NSLayoutConstraint.activate([
            h.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            h.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            h.view.topAnchor.constraint(equalTo: view.topAnchor),
            h.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        h.didMove(toParent: self)
        host = h

        let height = view.heightAnchor.constraint(equalToConstant: 290)
        height.priority = .defaultHigh
        height.isActive = true
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        engine.proxy = textDocumentProxy
        engine.reload()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        engine.pause()       // safe stop when the keyboard goes away
    }
}

struct KeyboardRoot: View {
    @ObservedObject var engine: TypingEngine
    var hasFullAccess: Bool
    var nextKeyboard: () -> Void

    private var statusText: String {
        switch engine.status {
        case .idle: return "Idle"
        case .typing: return "Typing"
        case .paused: return "Paused"
        }
    }
    private var statusColor: Color {
        switch engine.status {
        case .idle: return Brand.muted
        case .typing: return Brand.mint
        case .paused: return Brand.amber
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(hex: 0x0A0E1A), Color(hex: 0x16123A)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack(spacing: 10) {
                header
                if engine.license.valid { controls } else { locked }
            }
            .padding(12)
        }
    }

    private var header: some View {
        HStack(spacing: 8) {
            BrandLogo(size: 26)
            Text(brandName)
                .font(.system(size: 15, weight: .heavy))
                .foregroundStyle(Brand.gradient)
            Spacer()
            Text(statusText)
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(statusColor)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(statusColor.opacity(0.16))
                .clipShape(Capsule())
            Button(action: nextKeyboard) {
                Image(systemName: "globe").foregroundColor(.white).padding(6)
            }
        }
    }

    private var controls: some View {
        VStack(spacing: 10) {
            HStack {
                Text(engine.total == 0 ? "No lines" : "Line \(min(engine.position + 1, engine.total)) / \(engine.total)")
                    .font(.system(size: 17, weight: .heavy)).foregroundColor(.white)
                Spacer()
                Menu {
                    ForEach(engine.lists) { l in
                        Button(l.name) { engine.select(l) }
                    }
                } label: {
                    Label(engine.activeList?.name ?? "List", systemImage: "list.bullet")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(Brand.cyan)
                }
            }
            ProgressView(value: engine.total == 0 ? 0 : Double(min(engine.position + 1, engine.total)) / Double(engine.total))
                .tint(Brand.cyan)
            if !engine.message.isEmpty {
                Text(engine.message).font(.system(size: 11)).foregroundColor(Brand.muted).frame(maxWidth: .infinity, alignment: .leading)
            }

            HStack(spacing: 8) {
                KeyButton(title: "Play", icon: "play.fill", filled: true) { engine.play() }
                KeyButton(title: "Pause", icon: "pause.fill", filled: false) { engine.pause() }
                KeyButton(title: "Stop", icon: "stop.fill", filled: false) { engine.stop() }
                KeyButton(title: "Skip", icon: "forward.fill", filled: false) { engine.skip() }
            }

            HStack(spacing: 10) {
                Text("\(engine.config.wpm) WPM").font(.system(size: 13, weight: .bold)).foregroundColor(Brand.cyan).frame(width: 78, alignment: .leading)
                Slider(
                    value: Binding(
                        get: { fractionFromWpm(engine.config.wpm) },
                        set: { engine.setWpm(wpmFromFraction($0)) }
                    ),
                    in: 0...1
                ).tint(Brand.violet)
            }

            HStack {
                Toggle("Auto-send (Return)", isOn: Binding(
                    get: { engine.config.autoSend },
                    set: { engine.setAutoSend($0) }
                ))
                .font(.system(size: 12)).foregroundColor(.white).tint(Brand.violet)
                Button("Paste list") { engine.pasteList() }
                    .font(.system(size: 12, weight: .semibold)).foregroundColor(Brand.cyan)
            }
        }
    }

    private var locked: some View {
        VStack(spacing: 12) {
            Text("Access key required").font(.system(size: 17, weight: .heavy)).foregroundColor(.white)
            Text("Your Device ID: \(License.deviceID())").font(.system(size: 14, weight: .bold)).foregroundColor(Brand.cyan)
            Text("Activate inside the \(brandName) app, or copy your key and tap below.")
                .font(.system(size: 12)).foregroundColor(Brand.muted).multilineTextAlignment(.center)
            KeyButton(title: "Paste key", icon: "doc.on.clipboard", filled: true) { engine.activateFromClipboard() }
            if !hasFullAccess {
                Text("Turn on Allow Full Access in Settings to use paste.").font(.system(size: 11)).foregroundColor(Brand.amber)
            }
            if !engine.message.isEmpty {
                Text(engine.message).font(.system(size: 12)).foregroundColor(Brand.rose)
            }
        }
    }
}

struct KeyButton: View {
    let title: String
    let icon: String
    let filled: Bool
    let action: () -> Void
    var body: some View {
        Button {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            action()
        } label: {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 13, weight: .bold))
                Text(title).font(.system(size: 13, weight: .semibold))
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 12)
            .background(
                Group {
                    if filled {
                        RoundedRectangle(cornerRadius: 12).fill(LinearGradient(colors: [Brand.violet, Brand.cyan], startPoint: .leading, endPoint: .trailing))
                    } else {
                        RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.12))
                    }
                }
            )
        }
    }
}
