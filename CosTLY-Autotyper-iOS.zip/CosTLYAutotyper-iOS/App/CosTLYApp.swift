import SwiftUI
import UniformTypeIdentifiers

@main
struct CosTLYApp: App {
    var body: some Scene {
        WindowGroup { RootView() }
    }
}

final class AppModel: ObservableObject {
    @Published var lists: [Wordlist] { didSet { Store.shared.lists = lists } }
    @Published var activeID: String? { didSet { Store.shared.activeID = activeID } }
    @Published var config: TypingConfig { didSet { Store.shared.config = config } }
    @Published var license: LicenseInfo

    init() {
        var l = Store.shared.lists
        if l.isEmpty {
            l = [Wordlist(name: "Sample list", lines: ["Hello!", "This is line two.", "Edit this list in the Lists tab."])]
            Store.shared.lists = l
        }
        lists = l
        activeID = Store.shared.activeID ?? l.first?.id.uuidString
        config = Store.shared.config
        license = License.current()
    }

    func refreshLicense() { license = License.current() }

    func upsert(_ w: Wordlist) {
        if let i = lists.firstIndex(where: { $0.id == w.id }) {
            lists[i] = w
        } else {
            lists.append(w)
        }
        if activeID == nil { activeID = w.id.uuidString }
    }
}

struct RootView: View {
    @StateObject private var model = AppModel()
    var body: some View {
        Group {
            if model.license.valid { MainTabs() } else { ActivationView() }
        }
        .environmentObject(model)
        .preferredColorScheme(.dark)
        .onReceive(Timer.publish(every: 30, on: .main, in: .common).autoconnect()) { _ in model.refreshLicense() }
    }
}

struct MainTabs: View {
    var body: some View {
        TabView {
            SetupView().tabItem { Label("Setup", systemImage: "gearshape.fill") }
            ListsView().tabItem { Label("Lists", systemImage: "list.bullet") }
            SettingsView().tabItem { Label("Typing", systemImage: "keyboard") }
        }
        .tint(Brand.cyan)
    }
}

// MARK: - Shared UI helpers

struct Card<Content: View>: View {
    var border: Color
    let content: Content
    init(border: Color = Color.white.opacity(0.12), @ViewBuilder content: () -> Content) {
        self.border = border
        self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) { content }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Brand.surface)
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(border, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}

struct GradientButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .semibold))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 13)
            .background(RoundedRectangle(cornerRadius: 14).fill(LinearGradient(colors: [Brand.violet, Brand.cyan], startPoint: .leading, endPoint: .trailing)))
            .opacity(configuration.isPressed ? 0.8 : 1)
    }
}

struct BrandHeader: View {
    var body: some View {
        HStack(spacing: 12) {
            BrandLogo(size: 40)
            VStack(alignment: .leading, spacing: 2) {
                Text(brandName).font(.system(size: 20, weight: .heavy)).foregroundStyle(Brand.gradient)
                Text("System-wide auto typing, at your speed").font(.system(size: 12)).foregroundColor(Brand.muted)
            }
            Spacer()
        }
    }
}

// MARK: - Activation

struct ActivationView: View {
    @EnvironmentObject var model: AppModel
    @State private var key = ""
    @State private var error: String?
    @State private var copied = false

    var body: some View {
        ZStack {
            Brand.bg.ignoresSafeArea()
            ScrollView {
                VStack(spacing: 18) {
                    Spacer(minLength: 30)
                    BrandLogo(size: 92)
                    Text(brandName).font(.system(size: 28, weight: .heavy)).foregroundStyle(Brand.gradient)
                    Text("Enter your access key to continue").foregroundColor(Brand.muted)

                    Card {
                        Text("Your Device ID").font(.caption).foregroundColor(Brand.muted)
                        HStack {
                            Text(License.deviceID()).font(.system(size: 24, weight: .heavy)).foregroundColor(Brand.cyan)
                            Spacer()
                            Button(copied ? "Copied" : "Copy") {
                                UIPasteboard.general.string = License.deviceID()
                                copied = true
                            }
                            .foregroundColor(Brand.cyan)
                        }
                        Text("Send this ID to get a key made only for your phone.").font(.caption).foregroundColor(Brand.muted)
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        TextField("COSTLY-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX", text: $key)
                            .textInputAutocapitalization(.characters)
                            .disableAutocorrection(true)
                            .padding(14)
                            .background(Brand.surface2)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .foregroundColor(.white)
                        if let e = error { Text(e).font(.caption).foregroundColor(Brand.rose) }
                    }

                    HStack(spacing: 10) {
                        Button("Paste") {
                            if let s = UIPasteboard.general.string { key = s.trimmingCharacters(in: .whitespacesAndNewlines); error = nil }
                        }
                        .foregroundColor(.white)
                        .padding(.vertical, 13).padding(.horizontal, 22)
                        .background(Color.white.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        Button("Activate") {
                            error = License.activate(key)
                            model.refreshLicense()
                        }
                        .buttonStyle(GradientButtonStyle())
                    }
                    Text("\(brandName) - access key required").font(.caption).foregroundColor(Brand.muted).padding(.top, 10)
                }
                .padding(24)
            }
        }
    }
}

// MARK: - Setup

struct SetupView: View {
    @EnvironmentObject var model: AppModel
    @State private var testText = ""

    var body: some View {
        ZStack {
            Brand.bg.ignoresSafeArea()
            ScrollView {
                VStack(spacing: 14) {
                    BrandHeader()
                    Card(border: Brand.mint.opacity(0.35)) {
                        HStack {
                            Text("License").font(.headline).foregroundColor(.white)
                            Spacer()
                            Text(model.license.message).font(.caption.bold()).foregroundColor(Brand.mint)
                                .padding(.horizontal, 10).padding(.vertical, 4)
                                .background(Brand.mint.opacity(0.16)).clipShape(Capsule())
                        }
                        Text("Device ID: \(License.deviceID())").font(.caption).foregroundColor(Brand.muted)
                        Button("Remove key") { License.deactivate(); model.refreshLicense() }
                            .foregroundColor(Brand.rose)
                    }

                    Card {
                        Text("Add the keyboard").font(.headline).foregroundColor(.white)
                        Group {
                            Text("1. Settings > General > Keyboard > Keyboards > Add New Keyboard")
                            Text("2. Choose \(brandName)")
                            Text("3. Tap \(brandName) in the list and turn on Allow Full Access (needed for paste and haptics; the keyboard never uses the network)")
                            Text("4. In any chat, hold the globe key and pick \(brandName)")
                        }
                        .font(.system(size: 14)).foregroundColor(Brand.muted)
                        Button("Open Settings") {
                            if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                        }
                        .buttonStyle(GradientButtonStyle())
                    }

                    Card {
                        Text("Try it here").font(.headline).foregroundColor(.white)
                        TextField("Tap, switch to the keyboard, press Play", text: $testText)
                            .padding(12).background(Brand.surface2)
                            .clipShape(RoundedRectangle(cornerRadius: 12)).foregroundColor(.white)
                        Text("Note: iOS cannot tap Send buttons. Auto-send presses Return, so it only sends in apps where Return sends the message.")
                            .font(.caption).foregroundColor(Brand.muted)
                    }
                }
                .padding(16)
            }
        }
    }
}

// MARK: - Lists

struct ListsView: View {
    @EnvironmentObject var model: AppModel
    @State private var editing: Wordlist?
    @State private var importing = false

    var body: some View {
        NavigationView {
            ZStack {
                Brand.bg.ignoresSafeArea()
                List {
                    ForEach(model.lists) { l in
                        HStack(spacing: 12) {
                            Image(systemName: l.id.uuidString == model.activeID ? "largecircle.fill.circle" : "circle")
                                .foregroundColor(Brand.cyan)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(l.name).foregroundColor(.white).font(.headline)
                                Text("\(l.lineCount) lines · \(l.loop ? "Loop" : "Once") · \(l.shuffle ? "Shuffle" : "Sequential")")
                                    .font(.caption).foregroundColor(Brand.muted)
                            }
                            Spacer()
                            Button { editing = l } label: { Image(systemName: "pencil").foregroundColor(Brand.muted) }
                                .buttonStyle(.plain)
                        }
                        .contentShape(Rectangle())
                        .onTapGesture { model.activeID = l.id.uuidString }
                        .listRowBackground(Brand.surface)
                    }
                    .onDelete { model.lists.remove(atOffsets: $0) }
                }
                .listStyle(.insetGrouped)
            }
            .navigationTitle("Lists")
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button { importing = true } label: { Image(systemName: "square.and.arrow.down") }
                    Button { editing = Wordlist(name: "", lines: []) } label: { Image(systemName: "plus") }
                }
            }
            .sheet(item: $editing) { w in
                EditorView(list: w) { model.upsert($0) }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.plainText, .commaSeparatedText]) { result in
                handleImport(result)
            }
        }
        .navigationViewStyle(.stack)
    }

    private func handleImport(_ result: Result<URL, Error>) {
        guard case .success(let url) = result else { return }
        let ok = url.startAccessingSecurityScopedResource()
        defer { if ok { url.stopAccessingSecurityScopedResource() } }
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return }
        let isCSV = url.pathExtension.lowercased() == "csv"
        var lines: [String] = []
        for raw in text.replacingOccurrences(of: "\u{FEFF}", with: "").components(separatedBy: .newlines) {
            var l = raw.trimmingCharacters(in: .whitespaces)
            if l.isEmpty { continue }
            if isCSV && l.count >= 2 && l.hasPrefix("\"") && l.hasSuffix("\"") {
                l = String(l.dropFirst().dropLast()).replacingOccurrences(of: "\"\"", with: "\"")
            }
            lines.append(l)
        }
        guard !lines.isEmpty else { return }
        model.upsert(Wordlist(name: url.deletingPathExtension().lastPathComponent, lines: lines))
    }
}

struct EditorView: View {
    @Environment(\.dismiss) private var dismiss
    let original: Wordlist
    let onSave: (Wordlist) -> Void
    @State private var name: String
    @State private var text: String
    @State private var loop: Bool
    @State private var shuffle: Bool

    init(list: Wordlist, onSave: @escaping (Wordlist) -> Void) {
        self.original = list
        self.onSave = onSave
        _name = State(initialValue: list.name)
        _text = State(initialValue: list.lines.joined(separator: "\n"))
        _loop = State(initialValue: list.loop)
        _shuffle = State(initialValue: list.shuffle)
    }

    var body: some View {
        NavigationView {
            Form {
                Section("Name") { TextField("List name", text: $name) }
                Section("One message per line") {
                    TextEditor(text: $text).frame(minHeight: 200)
                }
                Section {
                    Toggle("Loop forever", isOn: $loop)
                    Toggle("Random order", isOn: $shuffle)
                }
            }
            .navigationTitle(original.name.isEmpty ? "New list" : "Edit list")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        var w = original
                        w.name = name.isEmpty ? "Untitled" : name
                        w.lines = text.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
                        w.loop = loop
                        w.shuffle = shuffle
                        onSave(w)
                        dismiss()
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

// MARK: - Typing settings

struct SettingsView: View {
    @EnvironmentObject var model: AppModel

    var body: some View {
        ZStack {
            Brand.bg.ignoresSafeArea()
            ScrollView {
                VStack(spacing: 14) {
                    BrandHeader()
                    Card {
                        Text("Speed").font(.headline).foregroundColor(.white)
                        HStack(alignment: .lastTextBaseline) {
                            Text("\(model.config.wpm)").font(.system(size: 34, weight: .heavy)).foregroundColor(Brand.cyan)
                            Text("WPM · ≈ \(String(format: "%.1f", model.config.baseCharDelayMs)) ms / char")
                                .font(.caption).foregroundColor(Brand.muted)
                        }
                        Slider(value: Binding(
                            get: { fractionFromWpm(model.config.wpm) },
                            set: { model.config.wpm = wpmFromFraction($0) }
                        ), in: 0...1).tint(Brand.violet)
                        Toggle("Human-like jitter (±15%)", isOn: $model.config.jitter).tint(Brand.violet).foregroundColor(.white)
                    }
                    Card {
                        Text("Sending").font(.headline).foregroundColor(.white)
                        Text("Delay between messages: \(String(format: "%.2f", Double(model.config.delayBetweenMs) / 1000.0)) s")
                            .foregroundColor(.white).font(.system(size: 14))
                        Slider(value: Binding(
                            get: { Double(model.config.delayBetweenMs) / 1000.0 },
                            set: { model.config.delayBetweenMs = Int(($0 * 20).rounded()) * 50 }
                        ), in: 0...10).tint(Brand.violet)
                        Toggle("Auto-send after each line (Return)", isOn: $model.config.autoSend).tint(Brand.violet).foregroundColor(.white)
                    }
                    Text("\(brandName) · built for speed").font(.caption).foregroundColor(Brand.muted).padding(.top, 8)
                }
                .padding(16)
            }
        }
    }
}
